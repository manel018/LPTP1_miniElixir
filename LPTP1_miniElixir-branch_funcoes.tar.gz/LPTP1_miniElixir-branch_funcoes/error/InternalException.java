package error;

public class InternalException extends RuntimeException {

    public InternalException(String msg) {
        super(msg);
    }

}
